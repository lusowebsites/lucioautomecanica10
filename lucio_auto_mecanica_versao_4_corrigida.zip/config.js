/* Sem identificadores válidos, nenhuma tag de medição é carregada.
Preencha ga4Id (G-...), adsId (AW-...) e os rótulos de conversão fornecidos pela sua conta.
Se importar conversões do GA4, não configure os mesmos eventos também como conversões diretas do Ads. */
window.SITE_ANALYTICS = { ga4Id: '', adsId: '', whatsappConversionLabel: '', phoneConversionLabel: '' };
